# This script accesses a specific pixel value,
# modifies it to white, and saves the updated image.

import cv2

image = cv2.imread('image.png')

print(f"Original pixel value at (50, 50): {image[50, 50]}")

image[50, 50] = [255, 255, 255]

cv2.imwrite('modified.png', image)
print("modified.png saved successfully")
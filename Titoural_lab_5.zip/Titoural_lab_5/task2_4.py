# This script converts an image to grayscale
# and saves the result as a new file.

import cv2

image = cv2.imread('image.png')
gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

cv2.imwrite('gray_image.png', gray_image)
print("gray_image.png saved successfully")
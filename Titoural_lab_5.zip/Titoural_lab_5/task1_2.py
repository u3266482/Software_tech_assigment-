# This script creates a 3x3 NumPy array filled with zeros.
# It then replaces the center element with the value 7 and prints the array.

import numpy as np

arr = np.zeros((3, 3), dtype=int)
arr[1, 1] = 7

print(arr)
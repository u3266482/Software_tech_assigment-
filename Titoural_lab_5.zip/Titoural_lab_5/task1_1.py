# This script creates a 1D NumPy array from 10 to 19.
# It then prints the array along with its shape, dimension, and data type.

import numpy as np

arr = np.arange(10, 20)

print("Array:", arr)
print("Shape:", arr.shape)
print("Dimension:", arr.ndim)
print("Data type:", arr.dtype)

# This script extracts data from a 3D NumPy array.
# It prints the temperatures for the second location
# across all years and months.

import numpy as np

temps = np.array([
    [[10, 15, 20], [25, 30, 35]],
    [[11, 16, 21], [26, 31, 36]]
])

print(temps[:, 1, :])
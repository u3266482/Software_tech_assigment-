# This script creates a 3D NumPy array filled with ones.
# It modifies a specific element and prints the entire array.

import numpy as np

arr = np.ones((2, 2, 3), dtype=int)
arr[1, 0, 2] = 5

print(arr)
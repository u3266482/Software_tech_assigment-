# This script creates an array using arange and computes
# the square root of each element.

import numpy as np

arr = np.arange(0, 16, 3)
sqrt_arr = np.sqrt(arr)

print(sqrt_arr)
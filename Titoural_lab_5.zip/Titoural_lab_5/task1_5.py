# This script creates a NumPy array and uses slicing
# to print every second element starting from the first.

import numpy as np

arr = np.array([2, 4, 6, 8, 10])

print(arr[::2])